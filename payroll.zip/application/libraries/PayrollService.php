<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PayrollService
{
    /** @var CI_Controller */
    protected $CI;

    public function __construct()
    {
        $this->CI = &get_instance();

        // Load all dependencies used in the payroll generation process
        $this->CI->load->model('Payroll_model');
        $this->CI->load->model('Attendance_model');     // already used in your controller earlier
        $this->CI->load->model('Loan_model');
        $this->CI->load->model('OtherDeduction_model');
        $this->CI->load->model('Cashadvance_model');
    }

    /**
     * SOA operation:
     * Generate payroll for the given date range and cutoff.
     *
     * This method encapsulates all business rules that were previously in
     * Payroll::generate() and returns the computed payroll rows.
     *
     * @param string $dateFrom
     * @param string $dateTo
     * @param string $cutoff
     * @param int    $settingsID
     * @return array $payroll_data (array of rows/objects)
     */
    public function generatePayroll($dateFrom, $dateTo, $cutoff, $settingsID)
    {
        // 1. Base payroll rows (hours, basic pay, etc.)
        $payroll_data = $this->CI->Payroll_model->generate_payroll($dateFrom, $dateTo, $cutoff);

        // 2. Other Deductions (e.g., materials/tools), grouped by personnelID
        $other_deductions = $this->CI->OtherDeduction_model
            ->get_deductions_by_date_range($dateFrom, $dateTo, $settingsID);

        $groupedDeductions = [];
        foreach ($other_deductions as $deduction) {
            $pid = (int) $deduction->personnelID;
            if (!isset($groupedDeductions[$pid])) {
                $groupedDeductions[$pid] = 0;
            }
            $groupedDeductions[$pid] += $deduction->amount;
        }

        // 3. Cash Advance totals by personnel
        $cash_advance_query = $this->CI->db->select('personnelID, SUM(amount) as total_amount')
            ->from('cashadvance')
            ->where('settingsID', $settingsID)
            ->where('date >=', $dateFrom)
            ->where('date <=', $dateTo)
            ->group_by('personnelID')
            ->get()->result();

        $cashAdvanceMap = [];
        foreach ($cash_advance_query as $ca) {
            $cashAdvanceMap[(int) $ca->personnelID] = $ca->total_amount;
        }

        // 4. Government Deductions (SSS, Pag-IBIG, PhilHealth, etc.) per personnel
        $govt_deductions_query = $this->CI->db->select('personnelID, description, amount')
            ->from('government_deductions')
            ->where('settingsID', $settingsID)
            ->where("(
                (deduct_from IS NULL OR deduct_from <= " . $this->CI->db->escape($dateTo) . ") AND
                (deduct_to   IS NULL OR deduct_to   >= " . $this->CI->db->escape($dateFrom) . ")
            )")
            ->get()->result();

        $govtMap = [];
        foreach ($govt_deductions_query as $deduct) {
            $pid = (int) $deduct->personnelID;
            if (!isset($govtMap[$pid])) {
                $govtMap[$pid] = [];
            }
            // e.g. 'SSS', 'Pag-IBIG', 'PhilHealth'
            $govtMap[$pid][$deduct->description] = $deduct->amount;
        }

        // 5. Enrich each payroll row with computed deductions & persist loan deductions
        foreach ($payroll_data as &$row) {
            $pid = (int) $row->personnelID;

            // Other Deduction
            $row->other_deduction = $groupedDeductions[$pid] ?? 0;

            // Personnel Loan Deduction
            $loan = $this->CI->Loan_model->get_personnel_loan($pid, $settingsID);
            $row->loan_deduction = $loan->monthly_deduction ?? 0;

            // Cash Advance
            $row->cash_advance = $cashAdvanceMap[$pid] ?? 0;

            // Government deductions breakdown
            $row->govt_sss     = $govtMap[$pid]['SSS']       ?? 0;
            $row->govt_pagibig = $govtMap[$pid]['Pag-IBIG']  ?? 0;
            $row->govt_phic    = $govtMap[$pid]['PhilHealth'] ?? 0;

            // Total Government Deductions
            $row->govt_total_deduction = $row->govt_sss + $row->govt_pagibig + $row->govt_phic;

            // Save loan deduction into payroll_deductions table
            if (!empty($row->loan_deduction)) {
                $this->CI->db->insert('payroll_deductions', [
                    'personnelID' => $pid,
                    'amount'      => $row->loan_deduction,
                    'description' => 'Personnel Loan',
                    'cutoff'      => $cutoff,
                    'deducted_on' => date('Y-m-d'),
                    'settingsID'  => $settingsID
                ]);
            }
        }
        unset($row); // safety when using references

        // 6. Auto-deduct due Cash Advances and save to payroll_deductions
        $due_advances = $this->CI->Cashadvance_model->get_due_cash_advances($cutoff, $settingsID);
        foreach ($due_advances as $advance) {
            $this->CI->Cashadvance_model->mark_cash_advance_deducted($advance->id);

            $this->CI->db->insert('payroll_deductions', [
                'personnelID' => $advance->personnelID,
                'amount'      => $advance->amount,
                'description' => 'Cash Advance',
                'cutoff'      => $cutoff,
                'deducted_on' => date('Y-m-d'),
                'settingsID'  => $settingsID
            ]);
        }

        // 7. Return enriched payroll data to the controller (service response)
        return $payroll_data;
    }

    /**
     * Optional helper for SOA:
     * Expose personnel list via the service as well.
     */
    public function getAllPersonnel()
    {
        return $this->CI->Payroll_model->get_all_personnel();
    }
}
