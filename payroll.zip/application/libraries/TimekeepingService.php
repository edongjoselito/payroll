<?php
defined('BASEPATH') or exit('No direct script access allowed');

class TimekeepingService
{
    protected $CI;

    public function __construct()
    {
        $this->CI = &get_instance();
        $this->CI->load->model('Attendance_model');
    }

    /**
     * SOA operation:
     * Get summarized attendance for a period.
     */
    public function getAttendanceSummary($employeeId, $dateFrom, $dateTo)
    {
        return $this->CI->Attendance_model->get_summary($employeeId, $dateFrom, $dateTo);
    }
}
