<?php
defined('BASEPATH') or exit('No direct script access allowed');

class LoanService
{
    protected $CI;

    public function __construct()
    {
        $this->CI = &get_instance();
        $this->CI->load->model('Loan_model');
    }

    /**
     * SOA operation:
     * Get all loan-related deductions for an employee for this cutoff.
     */
    public function getDeductionsForCutoff($employeeId, $cutoffId)
    {
        return $this->CI->Loan_model->get_deductions_for_cutoff($employeeId, $cutoffId);
    }
}
