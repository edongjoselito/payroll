<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Payroll extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        // Load service instead of manually loading all models here
        $this->load->library('PayrollService');

        // You can still load models for other simple things if needed
        $this->load->model('Payroll_model');
    }

    public function index()
    {
        // Option A: use service to get personnel
        $data['personnel'] = $this->payrollservice->getAllPersonnel();

        // Option B (old way): $data['personnel'] = $this->Payroll_model->get_all_personnel();
        // Both are acceptable, but A is more SOA-ish.

        $this->load->view('payroll/generate', $data);
    }

    public function generate()
    {
        $cutoff     = $this->input->post('cutoff');
        $dateFrom   = $this->input->post('date_from');
        $dateTo     = $this->input->post('date_to');
        $settingsID = $this->session->userdata('settingsID');

        // Basic validation (optional but nice)
        if (!$cutoff || !$dateFrom || !$dateTo || !$settingsID) {
            $this->session->set_flashdata('error', 'Missing required fields for payroll generation.');
            return redirect('Payroll');
        }

        // 🔹 SOA CALL: Controller → PayrollService
        $payroll_data = $this->payrollservice
            ->generatePayroll($dateFrom, $dateTo, $cutoff, $settingsID);

        // Same view as before, just cleaner controller
        $this->load->view('payroll/result', [
            'payroll'   => $payroll_data,
            'cutoff'    => $cutoff,
            'dateFrom'  => $dateFrom,
            'dateTo'    => $dateTo
        ]);
    }

    public function save()
    {
        $payroll = $this->input->post('payroll'); // assume it's an array
        $this->Payroll_model->save_payroll($payroll);

        $this->session->set_flashdata('success', 'Payroll saved successfully!');
        redirect('Payroll');
    }

    // ---------- NEW SIDEBAR

    public function generate_form()
    {
        // Load your project list (for dropdown selection if needed)
        $this->load->model('Project_model');
        $data['projects'] = $this->Project_model->get_all_projects();

        $this->load->view('payroll/sidebar_generate_form', $data);
    }
}
