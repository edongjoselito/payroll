                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                Payroll Management System 
                            </div>
                        </div>
                    </div>
                </footer>